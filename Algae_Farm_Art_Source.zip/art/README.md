# Editable artwork — Algae Farm 0.4

This scene combines Kenney's free Tiny Town 1.1 and Tiny Farm 1.0 tiles with original researcher, aerator and process equipment artwork. Both Kenney packs are CC0. Their original licenses are retained beside the atlases in `assets/vendor/`. Sources: https://kenney.nl/assets/tiny-town and https://kenney.nl/assets/tiny-farm.

## Piskel

Open `art/custom/down-walk.piskel` in https://www.piskelapp.com/ using Import → Browse .piskel files → Replace. It contains four 16×24 frames at 8 fps. This document was imported and its animation and 4-column PNG export settings reviewed in the actual Piskel editor. The original pixels were constructed with the included pixel-art script, then checked in Piskel; they were not drawn by hand in the editor.

`researcher.piskel` contains all 16 directional frames. The game's `researcher.png` has four columns and four rows: down, left, right, up. Keep frame 0 as idle and the foot anchor at (8,23). `aerator.piskel` contains six 16×16 frames; its PNG uses one row of six columns. Preserve hard transparency and export at 1×. The game displays these at 2×.

## Tiled

Open `art/maps/algae-farm.tmj` in Tiled. Keep the relative folder structure so both external `.tsj` tilesets resolve their images. The map was successfully exported to TMX and rendered by the official Tiled 1.12.2 tools. `Tiled_Map_Preview.png` is that editor render.

The Ground, Paths and Ground details layers paint Kenney terrain. Scenery contains decorations; paired tree halves share a `footY` depth anchor. Stations define collision footprints and process-building locations. Interactions define navigation destinations. These map layers and objects are actually consumed by the game. Algae raceways, buildings, pipes, weather and lighting are drawn and animated by `src/scene.mjs`; their full appearance is visible in the game rather than the terrain-only Tiled preview.

Save changes to the `.tmj` source. The `.tmx` is a checked export, not the build input. From the complete local game project, run `node tools/build.mjs` to embed the map and PNGs into `dist/index.html`. Editing a PNG alone will not update an existing built HTML file.

## Visual behavior

Water flow, paddle rotation and aeration run in cultivation. Clouds and soft shadows arrive after the first decision. Choosing LEDs lights the greenhouse windows. The researcher uses directional walking frames and stops on an idle frame. Reduced-motion preferences freeze decorative animation and use a static weather state. Gameplay quantities remain on model version 0.1.0.

No paid assets, accounts or services are required. The public art-source ZIP contains only reusable artwork, map files, the relevant rendering code and licenses; classroom notes and the original email are excluded.
