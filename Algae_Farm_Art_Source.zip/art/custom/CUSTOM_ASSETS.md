# Algae Farm original pixel artwork

Researcher and paddle aerator were drawn in logical pixels by tools/create-sprites.py. No third-party image pixels were included. The PNG sheets are ready for the game; the .piskel files are prepared for editing using Piskel model version 2. This generation step does not establish that Piskel itself was used.

researcher.png: 64 by 96; sixteen 16 by 24 frames. Rows down, left, right, up; four columns. Column 0 is neutral and idle-compatible. Feet use logical anchor (8, 23). Suggested display size 32 by 48 and animation at 8 fps.

aerator.png: six 16 by 16 frames in one horizontal row, total 96 by 16. Suggested 8 fps.

down-walk.piskel contains the four down-facing frames for an immediate Piskel animation preview. researcher.piskel contains all sixteen frames in row order. aerator.piskel contains the six machine frames.

Reuse terms follow the project owner's chosen license.
