// Art is authored at 16 px per tile and shown at 2x in the 32 px game world.
// The embedded data comes directly from the editable Tiled map and tilesets.
const WORLD_W = 1024, WORLD_H = 672;
const INK = '#304f49', LIGHT = '#f1e3b3';

function tileInfo(gid) {
  if (!gid) return null;
  const ref = [...SCENE_MAP.tilesets].reverse().find(t => gid >= t.firstgid);
  if (!ref) return null;
  const key = ref.source.includes('town') ? 'town' : 'farm';
  const set = SCENE_TILESETS[key];
  return {key, set, index: gid - ref.firstgid};
}

function tile(c, world, gid, x, y, width = 32, height = 32) {
  const info = tileInfo(gid); if (!info) return;
  const image = world.images[info.key]; if (!image?.naturalWidth) return;
  const {set, index} = info, margin = set.margin || 0, gap = set.spacing || 0;
  const sx = margin + index % set.columns * (set.tilewidth + gap);
  const sy = margin + Math.floor(index / set.columns) * (set.tileheight + gap);
  c.drawImage(image, sx, sy, set.tilewidth, set.tileheight, Math.round(x), Math.round(y), width, height);
}

export function cacheSceneGround(world) {
  const surface = document.createElement('canvas'); surface.width = WORLD_W; surface.height = WORLD_H;
  const c = surface.getContext('2d'); c.imageSmoothingEnabled = false;
  c.fillStyle = '#87a95e'; c.fillRect(0, 0, WORLD_W, WORLD_H);
  // Tiny Town/Farm have no river tiles: this narrow channel is original art.
  rect(c, 960, 0, 64, WORLD_H, '#61949b'); rect(c, 960, 0, 6, WORLD_H, '#477a76');
  rect(c, 966, 0, 4, WORLD_H, '#8bb5aa');
  for (const layer of SCENE_MAP.layers.filter(l => l.type === 'tilelayer' && l.visible !== false)) {
    layer.data.forEach((gid, i) => tile(c, world, gid, i % layer.width * 32, Math.floor(i / layer.width) * 32));
  }
  world.ground = surface;
}

function rect(c, x, y, w, h, color) {
  c.fillStyle = color; c.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h));
}

function pixelPanel(c, x, y, w, h, color, corner = 4) {
  rect(c, x + corner, y, w - corner * 2, h, color);
  rect(c, x, y + corner, w, h - corner * 2, color);
}

function shadow(c, x, y, w, h = 14) {
  pixelPanel(c, x + 6, y + 5, w, h, '#304f492c', 6);
}

function sprite(c, image, frame, row, fw, fh, x, y) {
  if (!image?.naturalWidth) return;
  c.drawImage(image, frame * fw, row * fh, fw, fh, Math.round(x), Math.round(y), fw * 2, fh * 2);
}

function pond(c, world, x, y, w, t, row) {
  shadow(c, x, y + 50, w, 18);
  pixelPanel(c, x, y, w, 60, '#6b7967', 8);
  pixelPanel(c, x, y - 4, w, 58, '#c6c1a1', 8);
  pixelPanel(c, x + 4, y, w - 8, 48, '#e0d9b6', 6);
  pixelPanel(c, x + 10, y + 5, w - 20, 39, '#375f50', 5);
  pixelPanel(c, x + 12, y + 9, w - 24, 32, '#4d865c', 4);
  rect(c, x + 16, y + 9, w - 32, 5, '#74a067');
  rect(c, x + 14, y + 37, w - 28, 4, '#30584d');
  // A central island makes the raceway legible; the water moves around it.
  pixelPanel(c, x + 46, y + 24, w - 92, 6, '#b0ad8b', 2);
  rect(c, x + 52, y + 24, w - 104, 2, '#e6dfbd');
  for (let i = 0; i < 9; i++) {
    const drift = world.reduced ? 0 : (t / 95 + i * 17) % 28;
    const xx = x + 18 + i * 27 + (row ? -drift / 3 : drift / 3);
    const yy = y + (i % 2 ? 34 : 17);
    rect(c, xx, yy, 7 + i % 3 * 2, 2, i % 3 ? '#72a974' : '#98bd82');
  }
  const frame = world.reduced ? 0 : Math.floor(t / 135) % 6;
  for (const offset of [18, w - 46]) {
    sprite(c, world.images.aerator, frame, 0, 16, 16, x + offset, y + 10);
    for (let j = 0; j < 3; j++) {
      const progress = world.reduced ? .4 : (t / 800 + j / 3 + row / 2) % 1;
      const bx = x + offset + 17 + (j - 1) * 7, by = y + 30 - progress * 15;
      rect(c, bx, by, 2, 2, progress > .75 ? '#80ac7c' : '#c3dba2');
    }
  }
  for (let i = 0; i < w - 16; i += 24) rect(c, x + 9 + i, y + 49, 14, 2, '#a7a58a');
}

function cultivation(c, world, s, t) {
  const x = s.x * 32, y = s.y * 32, w = s.w * 32;
  // Feed and return pipes connect both ponds to the pump cabinet.
  rect(c, x + w - 8, y + 28, 20, 70, '#526e62');
  rect(c, x + w - 5, y + 26, 14, 70, '#bed0b0');
  rect(c, x + w - 2, y + 26, 4, 70, '#e2e8c8');
  pond(c, world, x, y, w, t, 0); pond(c, world, x, y + 66, w, t + 250, 1);
  pixelPanel(c, x + w - 34, y + 123, 32, 22, '#526e62', 2);
  rect(c, x + w - 30, y + 121, 24, 18, '#d2d7b4');
  rect(c, x + w - 26, y + 125, 9, 6, '#426b65');
  rect(c, x + w - 13, y + 126, 3, 3, '#91bf74');
  rect(c, x + 8, y - 12, 47, 12, '#cfb57e');
  rect(c, x + 12, y - 10, 39, 2, '#f0deb0');
  c.fillStyle = INK; c.font = 'bold 8px system-ui'; c.textAlign = 'center'; c.fillText('RACEWAY', x + 31, y - 3);
}

function greenhouse(c, world, s) {
  const x = s.x * 32, y = s.y * 32, w = s.w * 32, h = s.h * 32;
  shadow(c, x - 3, y + h - 10, w + 6, 24);
  pixelPanel(c, x, y + 31, w, h - 31, '#56786c', 4);
  rect(c, x + 4, y + 39, w - 8, h - 51, '#638f7b');
  // A stepped arched roof uses the same two-pixel edges as the sprite art.
  for (let i = 0; i < 5; i++) {
    rect(c, x + 4 + i * 6, y + 26 - i * 8, w - 8 - i * 12, 10, i < 2 ? '#aac5b0' : '#bdd0b6');
  }
  rect(c, x + 32, y - 10, w - 64, 6, '#e3e5c9');
  rect(c, x - 4, y + 30, w + 8, 6, '#e1dfbd');
  const light = world.led;
  for (let i = 0; i < 5; i++) {
    const px = x + 11 + i * 41;
    rect(c, px, y + 43, 32, 88, '#497763');
    rect(c, px + 3, y + 47, 26, 74, light ? '#b0ba72' : '#81ac91');
    rect(c, px + 6, y + 54, 4, 56, light ? '#d6d797' : '#adccb0');
    rect(c, px + 14, y + 82, 12, 29, '#467c59');
    rect(c, px + 13, y + 79, 14, 5, '#90b077');
    rect(c, px + 3, y + 48, 26, 3, light ? '#fff0a6' : '#b9d2b4');
    if (light) {
      rect(c, px + 1, y + 53, 30, 28, '#f3df7238');
      rect(c, px + 3, y + 81, 26, 22, '#f3df721c');
    }
    rect(c, px - 6, y + 35, 5, h - 42, '#d9dfbe');
    rect(c, px + 1, y + 123, 30, 5, '#b7c4a3');
  }
  rect(c, x + w - 6, y + 35, 5, h - 42, '#d9dfbe');
  rect(c, x - 1, y + h - 13, w + 2, 9, '#aaa98c');
  rect(c, x + w / 2 - 17, y + h - 41, 34, 37, '#365d51');
  rect(c, x + w / 2 - 12, y + h - 37, 24, 28, '#8bb49a');
  rect(c, x + w / 2 + 7, y + h - 25, 3, 4, '#e9d49a');
  rect(c, x + w / 2 - 22, y + h - 4, 44, 5, '#ded5b0');
}

function processing(c, world, s) {
  const x = s.x * 32, y = s.y * 32, w = s.w * 32, h = s.h * 32;
  shadow(c, x - 8, y + h - 7, w + 13, 22);
  pixelPanel(c, x, y + 29, w, h - 29, '#b99c72', 4);
  rect(c, x + 4, y + 37, w - 8, h - 45, '#e0c28e');
  rect(c, x + 3, y + h - 14, w - 6, 9, '#b29269');
  for (let yy = y + 49; yy < y + h - 15; yy += 18) {
    rect(c, x + 5, yy, w - 10, 2, '#d0b180');
    for (let xx = x + 12 + (yy % 36 ? 0 : 12); xx < x + w; xx += 36) rect(c, xx, yy - 14, 2, 14, '#d0b180');
  }
  rect(c, x - 8, y + 2, w + 16, 43, '#715748');
  rect(c, x - 6, y - 4, w + 12, 42, '#a36b4e');
  rect(c, x + 4, y - 12, w - 8, 10, '#be845b');
  for (let yy = 0; yy < 3; yy++) {
    rect(c, x - 2, y + yy * 12, w + 4, 2, '#c28b60');
    for (let xx = 0; xx < 7; xx++) rect(c, x + 10 + xx * 31 + yy % 2 * 12, y + yy * 12 + 2, 2, 9, '#925d48');
  }
  for (let i = 0; i < 3; i++) {
    const px = x + 13 + i * 60;
    rect(c, px, y + 2, 51, 28, '#304f54'); rect(c, px + 3, y + 5, 45, 21, '#416f7a');
    for (let n = 1; n < 3; n++) rect(c, px + 3 + n * 15, y + 5, 1, 21, '#91b2b0');
    rect(c, px + 3, y + 15, 45, 1, '#91b2b0');
  }
  rect(c, x + 20, y + 58, 46, 39, '#856f53'); rect(c, x + 23, y + 61, 40, 30, '#638c88');
  rect(c, x + 28, y + 64, 30, 3, '#b7d3bc'); rect(c, x + 42, y + 61, 3, 30, '#d1c19b');
  rect(c, x + 119, y + 60, 44, 68, '#6e6750'); rect(c, x + 123, y + 64, 36, 61, '#967a54');
  rect(c, x + 125, y + 70, 2, 48, '#b69968'); rect(c, x + 151, y + 93, 3, 5, '#e0d5a6');
  // Small pressure vessel and pipe by the workshop door.
  pixelPanel(c, x + 183, y + 58, 29, 52, '#72958b', 5);
  rect(c, x + 187, y + 62, 6, 38, '#b8c9ad'); rect(c, x + 182, y + 62, 31, 5, '#d2d6b5');
  rect(c, x + 192, y + 52, 9, 7, '#bdc4a1'); rect(c, x + 201, y + 83, 15, 6, '#cad0ad');
  if (['recovery', 'delivery', 'results'].includes(world.phase)) crate(c, x + 72, y + h - 22, true);
}

function tank(c, x, y, w, h, t, reduced) {
  shadow(c, x, y + h - 5, w, 15);
  pixelPanel(c, x, y + 5, w, h - 5, '#4d776e', 6);
  rect(c, x + 5, y + 11, w - 12, h - 16, '#7a9c8c'); rect(c, x + 9, y + 13, 8, h - 20, '#a5bd9f');
  pixelPanel(c, x - 3, y, w + 6, 15, '#c2ccb0', 5); rect(c, x + 5, y + 3, w - 10, 3, '#e6e4c6');
  rect(c, x + 1, y + h - 18, w - 2, 6, '#b8c4a6');
  rect(c, x + w / 2 - 4, y + 28, 13, h - 56, '#365e59');
  rect(c, x + w / 2 - 1, y + 32, 7, h - 64, '#7eb7ac');
  const offset = reduced ? 0 : Math.floor(t / 240) % 3 * 3;
  for (let i = 0; i < 3; i++) rect(c, x + w / 2 + 1, y + 36 + i * 8 - offset, 2, 2, '#d1dfbe');
}

function recovery(c, world, s, t) {
  const x = s.x * 32, y = s.y * 32;
  rect(c, x + 38, y + 91, 101, 12, '#4d776e'); rect(c, x + 38, y + 91, 101, 5, '#cfcead');
  rect(c, x + 130, y + 80, 10, 45, '#638578'); rect(c, x + 130, y + 80, 4, 45, '#cbd0ad');
  tank(c, x + 8, y + 6, 77, 106, t, world.reduced); tank(c, x + 115, y + 34, 65, 78, t + 180, world.reduced);
  rect(c, x + 41, y + 111, 12, 14, '#738b73'); rect(c, x + 38, y + 120, 18, 5, '#bbc4a1');
  rect(c, x + 94, y + 89, 4, 14, '#335e55'); rect(c, x + 88, y + 93, 16, 5, '#d3a06a');
}

function crate(c, x, y, product = false) {
  rect(c, x, y, 28, 24, '#8b6b43'); rect(c, x + 2, y, 24, 20, '#ba9159');
  rect(c, x + 3, y + 3, 22, 3, '#e0b771'); rect(c, x + 3, y + 13, 22, 3, '#e0b771');
  rect(c, x + 4, y + 3, 3, 15, '#8c6b43'); rect(c, x + 21, y + 3, 3, 15, '#8c6b43');
  if (product) {rect(c, x + 10, y - 3, 9, 10, '#6c9768'); rect(c, x + 12, y - 6, 5, 4, '#d6dab6');}
}

function delivery(c, s) {
  const x = s.x * 32, y = s.y * 32, w = s.w * 32;
  shadow(c, x, y + 86, w, 18);
  rect(c, x + 6, y + 24, w - 12, 65, '#c9af7f');
  rect(c, x + 12, y + 36, w - 24, 42, '#628475');
  rect(c, x + 12, y + 30, 7, 61, '#b18a56'); rect(c, x + w - 19, y + 30, 7, 61, '#b18a56');
  rect(c, x - 6, y + 14, w + 12, 24, '#806548');
  for (let i = 0; i < 12; i++) {
    const xx = x - 5 + i * 17;
    rect(c, xx, y + 8, 17, 24, i % 2 ? '#cf8c52' : '#eee0ab');
    rect(c, xx, y + 29, 17, 8, i % 2 ? '#b77649' : '#cbbc8d');
  }
  rect(c, x + 10, y + 70, w - 20, 13, '#8e6b44'); rect(c, x + 12, y + 68, w - 24, 5, '#d1b27b');
  crate(c, x + 22, y + 49, true); crate(c, x + 54, y + 47, true);
  rect(c, x + 118, y + 48, 16, 18, '#e0d8b3'); rect(c, x + 121, y + 51, 10, 10, '#71a376');
  rect(c, x + 146, y + 52, 12, 14, '#c5caa6'); rect(c, x + 149, y + 49, 6, 4, '#6d8f78');
  rect(c, x + 16, y + 84, 7, 12, '#756344'); rect(c, x + w - 24, y + 84, 7, 12, '#756344');
}

function stationLabel(c, world, id, s, t) {
  const x = (s.x + s.w / 2) * 32, y = s.y * 32 - 40;
  const active = id === world.active, width = Math.max(96, s.name.length * 7 + 24);
  pixelPanel(c, x - width / 2 + 2, y + 3, width, 24, '#3f5b4438', 3);
  pixelPanel(c, x - width / 2, y, width, 24, active ? '#f5dda2' : '#e9e2bf', 3);
  rect(c, x - width / 2 + 6, y + 4, 3, 16, active ? '#b88346' : '#8b9d78');
  c.fillStyle = INK; c.font = '600 12px system-ui'; c.textAlign = 'center'; c.fillText(s.name, x + 3, y + 16);
  if (active && world.enabled) {
    const px = (s.point[0] + .5) * 32, py = (s.point[1] + .5) * 32;
    const lift = world.reduced ? 0 : Math.round(Math.sin(t / 320) * 3);
    rect(c, px - 12, py + 3, 24, 2, '#f9e6ae'); rect(c, px - 15, py - 1, 2, 7, '#f9e6ae'); rect(c, px + 13, py - 1, 2, 7, '#f9e6ae');
    const by = y + 2 + lift, bx = x - width / 2 - 17;
    pixelPanel(c, bx - 10, by, 20, 20, '#365d50', 3);
    rect(c, bx - 3, by + 4, 6, 7, '#ffe5a0'); rect(c, bx - 6, by + 11, 12, 3, '#ffe5a0'); rect(c, bx - 3, by + 14, 6, 3, '#ffe5a0');
  }
}

function atmosphere(c, world, t) {
  const mix = world.reduced ? +world.cloudy : world.weatherMix;
  if (!mix) return;
  rect(c, 0, 0, WORLD_W, WORLD_H, `rgba(66,85,98,${mix * .13})`);
  // Broad cloud shadows drift over the fields without hiding the controls.
  for (let i = 0; i < 3; i++) {
    const x = world.reduced ? i * 360 - 60 : (t / 48 + i * 410) % 1450 - 280;
    const y = 46 + i * 172;
    pixelPanel(c, x, y + 30, 230, 54, `rgba(43,65,70,${mix * .09})`, 18);
    pixelPanel(c, x + 34, y + 14, 154, 68, `rgba(43,65,70,${mix * .05})`, 16);
  }
  // Clouds stay near the northern edge; the greenhouses remain readable.
  c.globalAlpha = mix * .86;
  for (let i = 0; i < 3; i++) {
    const x = world.reduced ? i * 400 : (t / 90 + i * 400) % 1350 - 170;
    const y = 2 + i % 2 * 18;
    pixelPanel(c, x, y + 12, 125, 25, '#bac7bd', 8);
    pixelPanel(c, x + 8, y + 4, 105, 25, '#e2e4cd', 9);
    pixelPanel(c, x + 32, y - 4, 51, 21, '#edecda', 8);
  }
  c.globalAlpha = 1;
}

export function drawFarmScene(world, t) {
  const c = world.ctx, w = world.width || WORLD_W, h = world.height || 560, scale = world.scale || 1;
  world.camX = Math.round(Math.max(0, Math.min(Math.max(0, WORLD_W - w / scale), world.avatar.x - w / scale / 2)));
  world.camY = Math.round(Math.max(0, Math.min(Math.max(0, WORLD_H - h / scale), world.avatar.y - h / scale / 2)));
  c.setTransform(world.dpr || 1, 0, 0, world.dpr || 1, 0, 0); c.clearRect(0, 0, w, h);
  c.fillStyle = '#86a65e'; c.fillRect(0, 0, w, h);
  if (!world.artReady) {c.fillStyle = INK; c.font = '14px system-ui'; c.textAlign = 'center'; c.fillText('Preparando a fazenda…', w / 2, h / 2); return;}
  c.save(); c.imageSmoothingEnabled = false; c.scale(scale, scale); c.translate(-world.camX, -world.camY);
  if (world.ground) c.drawImage(world.ground, 0, 0);
  const clock = world.reduced ? 0 : t;
  // River shimmer is an original overlay beside the Kenney terrain.
  for (let i = 0; i < 16; i++) rect(c, 965 + i % 2 * 28 + (clock / 160 + i * 5) % 9, 17 + i * 42, 13, 2, '#c4d7c077');
  if (world.path.length) {
    c.globalAlpha = .6;
    for (let i = 1; i < world.path.length; i += 2) {const p = world.path[i]; rect(c, p.x - 2, p.y - 1, 4, 3, '#f9efc8');}
    c.globalAlpha = 1;
  }
  const things = [];
  for (const layer of SCENE_MAP.layers.filter(l => l.type === 'objectgroup' && l.name === 'Scenery')) {
    for (const o of layer.objects) if (o.gid) {
      const properties = Object.fromEntries((o.properties || []).map(p => [p.name, p.value]));
      things.push({depth: (properties.footY ?? o.y) * 2, draw: () => {
        if (properties.castShadow !== false) shadow(c, o.x * 2, o.y * 2 - 9, o.width * 2, 12);
        tile(c, world, o.gid, o.x * 2, (o.y - o.height) * 2, o.width * 2, o.height * 2);
      }});
    }
  }
  for (const [id, s] of Object.entries(STATIONS)) things.push({depth: (s.y + s.h) * 32, draw: () => {
    if (id === 'cultivation') cultivation(c, world, s, clock);
    else if (id === 'weather') greenhouse(c, world, s);
    else if (id === 'processing') processing(c, world, s);
    else if (id === 'recovery') recovery(c, world, s, clock);
    else delivery(c, s);
  }});
  things.push({depth: world.avatar.y, draw: () => {
    const x = Math.round(world.avatar.x), y = Math.round(world.avatar.y);
    shadow(c, x - 15, y - 8, 24, 8);
    const frame = world.moving && !world.reduced ? Math.floor(world.walkTime * 8) % 4 : 0;
    const row = {down: 0, left: 1, right: 2, up: 3}[world.avatar.facing] ?? 0;
    sprite(c, world.images.researcher, frame, row, 16, 24, x - 16, y - 46);
  }});
  things.sort((a, b) => a.depth - b.depth).forEach(o => o.draw());
  atmosphere(c, world, clock);
  for (const [id, s] of Object.entries(STATIONS)) stationLabel(c, world, id, s, clock);
  c.restore();
}
