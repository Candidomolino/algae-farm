// Art is authored at 16 px per tile and shown at 2x in the 32 px game world.
// The embedded data comes directly from the editable Tiled map and tilesets.
import {SECRETS} from './secrets.mjs';
const WORLD_W = 1024, WORLD_H = 672;
const INK = '#304f49', LIGHT = '#f1e3b3';

function tileInfo(gid) {
  if (!gid) return null;
  const ref = [...SCENE_MAP.tilesets].reverse().find(t => gid >= t.firstgid);
  if (!ref) return null;
  const key = ref.source.includes('town') ? 'town' : 'farm';
  const set = SCENE_TILESETS[key];
  return {key, set, index: gid - ref.firstgid};
}

function tile(c, world, gid, x, y, width = 32, height = 32) {
  const info = tileInfo(gid); if (!info) return;
  const image = world.images[info.key]; if (!image?.naturalWidth) return;
  const {set, index} = info, margin = set.margin || 0, gap = set.spacing || 0;
  const sx = margin + index % set.columns * (set.tilewidth + gap);
  const sy = margin + Math.floor(index / set.columns) * (set.tileheight + gap);
  c.drawImage(image, sx, sy, set.tilewidth, set.tileheight, Math.round(x), Math.round(y), width, height);
}

export function cacheSceneGround(world) {
  const surface = document.createElement('canvas'); surface.width = WORLD_W; surface.height = WORLD_H;
  const c = surface.getContext('2d'); c.imageSmoothingEnabled = false;
  c.fillStyle = '#87a95e'; c.fillRect(0, 0, WORLD_W, WORLD_H);
  // Tiny Town/Farm have no river tiles: this narrow channel is original art.
  rect(c, 960, 0, 64, WORLD_H, '#61949b'); rect(c, 960, 0, 6, WORLD_H, '#477a76');
  rect(c, 966, 0, 4, WORLD_H, '#8bb5aa');
  for (const layer of SCENE_MAP.layers.filter(l => l.type === 'tilelayer' && l.visible !== false)) {
    layer.data.forEach((gid, i) => tile(c, world, gid, i % layer.width * 32, Math.floor(i / layer.width) * 32));
  }
  world.ground = surface;
}

function rect(c, x, y, w, h, color) {
  c.fillStyle = color; c.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h));
}

function pixelPanel(c, x, y, w, h, color, corner = 4) {
  rect(c, x + corner, y, w - corner * 2, h, color);
  rect(c, x, y + corner, w, h - corner * 2, color);
}

function shadow(c, x, y, w, h = 14) {
  pixelPanel(c, x + 6, y + 5, w, h, '#304f492c', 6);
}

function sprite(c, image, frame, row, fw, fh, x, y) {
  if (!image?.naturalWidth) return;
  c.drawImage(image, frame * fw, row * fh, fw, fh, Math.round(x), Math.round(y), fw * 2, fh * 2);
}

function farmLevel(world, id) {
  const level = world.farmUpgrades?.[id];
  return Number.isFinite(level) ? Math.max(0, Math.min(3, Math.floor(level))) : 0;
}

function operatingLight(c, world, x, y, t) {
  const bright = world.reduced || Math.sin(t / 1100) > -.35;
  rect(c, x - 2, y - 2, 8, 8, bright ? '#cee3a12b' : '#9cb67c18');
  rect(c, x, y, 4, 4, bright ? '#c7df9a' : '#8fb47f');
  rect(c, x, y, 2, 2, bright ? '#e6edb9' : '#aec58b');
}

function feedBarrel(c, x, y, color) {
  pixelPanel(c, x, y + 3, 22, 30, '#506b5b', 3);
  rect(c, x + 3, y + 6, 16, 24, color);
  rect(c, x + 4, y + 7, 4, 20, '#c9d2a8');
  pixelPanel(c, x - 1, y, 24, 7, '#c5c7a0', 2);
  rect(c, x + 1, y + 23, 20, 4, '#b3bea0');
  rect(c, x + 10, y + 11, 6, 7, '#e2dbb2');
}

const CULTURE_VISUALS = {
  chlorella: {water: '#4d865c', rim: '#375f50', reflection: '#74a067', shade: '#30584d', cell: '#9bbc7f', glint: '#c2d69c', cellShade: '#79a36c'},
  nannochloropsis: {water: '#758557', rim: '#4b634c', reflection: '#9ca56b', shade: '#4c654b', cell: '#bbb36e', glint: '#d0ce95', cellShade: '#9bad70'},
  tetraselmis: {water: '#478576', rim: '#345f57', reflection: '#77a28a', shade: '#315e53', cell: '#9fc49a', glint: '#c0d8ab', cellShade: '#79ab8c'}
};

function cultureCells(c, world, x, y, w, t, row, culture) {
  const species = world.speciesId || 'chlorella', span = w - 48;
  // Enlarged illustrative cell forms stay in the two water lanes, clear of the island.
  for (let lane = 0; lane < 2; lane++) for (let i = 0; i < Math.floor(span / 31); i++) {
    const drift = world.reduced ? 0 : t / 180 * (lane === row ? 1 : -1);
    const xx = x + 18 + ((i * 31 + row * 11 + lane * 13 + drift) % span + span) % span;
    const yy = y + (lane ? 32 : 16) + i % 2;
    if (species === 'nannochloropsis') {
      // Small green-gold dots contrast with the larger round starter cells.
      rect(c, xx + 1, yy + 1, 2, 3, culture.cell);
      rect(c, xx, yy + 2, 3, 1, culture.cell);
      rect(c, xx + 6, yy + 3, 2, 2, culture.glint);
      if (i % 2) rect(c, xx + 10, yy, 2, 2, culture.cellShade);
    } else if (species === 'tetraselmis') {
      pixelPanel(c, xx, yy + 1, 10, 4, culture.cell, 1);
      rect(c, xx + 2, yy + 1, 4, 1, culture.glint);
      rect(c, xx + 4, yy + 4, 4, 1, culture.cellShade);
      rect(c, xx - 3, yy + 2, 3, 1, culture.cellShade);
    } else {
      pixelPanel(c, xx, yy, 6, 6, culture.cell, 2);
      rect(c, xx + 2, yy + 1, 2, 2, culture.glint);
      rect(c, xx + 2, yy + 4, 2, 1, culture.cellShade);
    }
  }
}

function pond(c, world, x, y, w, t, row) {
  const culture = Object.hasOwn(CULTURE_VISUALS, world.speciesId) ? CULTURE_VISUALS[world.speciesId] : CULTURE_VISUALS.chlorella;
  shadow(c, x, y + 50, w, 18);
  pixelPanel(c, x, y, w, 60, '#6b7967', 8);
  pixelPanel(c, x, y - 4, w, 58, '#c6c1a1', 8);
  pixelPanel(c, x + 4, y, w - 8, 48, '#e0d9b6', 6);
  pixelPanel(c, x + 10, y + 5, w - 20, 39, culture.rim, 5);
  pixelPanel(c, x + 12, y + 9, w - 24, 32, culture.water, 4);
  rect(c, x + 16, y + 9, w - 32, 5, culture.reflection);
  rect(c, x + 14, y + 37, w - 28, 4, culture.shade);
  // A central island makes the raceway legible; the water moves around it.
  pixelPanel(c, x + 46, y + 24, w - 92, 6, '#b0ad8b', 2);
  rect(c, x + 52, y + 24, w - 104, 2, '#e6dfbd');
  cultureCells(c, world, x, y, w, t, row, culture);
  const frame = world.reduced ? 0 : Math.floor(t / 135) % 6;
  for (const offset of [18, w - 46]) {
    sprite(c, world.images.aerator, frame, 0, 16, 16, x + offset, y + 10);
    for (let j = 0; j < 3; j++) {
      const progress = world.reduced ? .4 : (t / 800 + j / 3 + row / 2) % 1;
      const bx = x + offset + 17 + (j - 1) * 7, by = y + 30 - progress * 15;
      rect(c, bx, by, 2, 2, progress > .75 ? '#80ac7c' : '#c3dba2');
    }
  }
  for (let i = 0; i < w - 16; i += 24) rect(c, x + 9 + i, y + 49, 14, 2, '#a7a58a');
}

function cultivation(c, world, s, t) {
  const x = s.x * 32, y = s.y * 32, w = s.w * 32;
  const level = farmLevel(world, 'cultivation'), pondWidth = w - (level >= 2 ? 58 : 0);
  if (level >= 2) {
    // The feed bay occupies the pond's existing footprint, keeping paths clear.
    pixelPanel(c, x + w - 56, y, 56, 127, '#8b9b75', 4);
    rect(c, x + w - 52, y + 4, 48, 118, '#b5b99a');
    rect(c, x + w - 13, y + 12, 6, 103, '#526e62');
    rect(c, x + w - 12, y + 12, 2, 103, '#e1dfba');
    rect(c, x + pondWidth - 4, y + 24, 42, 6, '#c4d0af');
    rect(c, x + pondWidth - 4, y + 88, 42, 6, '#c4d0af');
  }
  // Feed and return pipes connect both ponds to the pump cabinet.
  rect(c, x + pondWidth - 8, y + 28, 20, 70, '#526e62');
  rect(c, x + pondWidth - 5, y + 26, 14, 70, '#bed0b0');
  rect(c, x + pondWidth - 2, y + 26, 4, 70, '#e2e8c8');
  pond(c, world, x, y, pondWidth, t, 0); pond(c, world, x, y + 66, pondWidth, t + 250, 1);
  if (!level) {
    pixelPanel(c, x + w - 34, y + 123, 32, 22, '#526e62', 2);
    rect(c, x + w - 30, y + 121, 24, 18, '#d2d7b4');
    rect(c, x + w - 26, y + 125, 9, 6, '#426b65');
    rect(c, x + w - 13, y + 126, 3, 3, '#91bf74');
  } else {
    const cabinetX = x + w - (level >= 2 ? 50 : 66), cabinetY = y + 102;
    pixelPanel(c, cabinetX, cabinetY, level >= 2 ? 44 : 60, 25, '#45685b', 3);
    rect(c, cabinetX + 3, cabinetY + 2, level >= 2 ? 38 : 54, 19, '#d0d4ae');
    rect(c, cabinetX + 7, cabinetY + 6, 15, 8, '#416a62');
    rect(c, cabinetX + 9, cabinetY + 8, 10, 2, '#a5c18f');
    rect(c, cabinetX + 25, cabinetY + 6, 3, 10, '#a6b18d');
    rect(c, cabinetX + 30, cabinetY + 6, 3, 10, '#a6b18d');
    rect(c, cabinetX + 5, cabinetY - 5, 7, 7, '#b7c6a7');
    rect(c, cabinetX + 8, cabinetY - 38, 4, 34, '#c8d2b0');
    if (level === 1) {
      rect(c, cabinetX - 15, cabinetY - 38, 27, 4, '#c8d2b0');
      rect(c, cabinetX + 43, cabinetY + 7, 8, 6, '#83a87d');
    }
    if (level >= 2) {
      feedBarrel(c, x + w - 47, y + 13, '#779a78');
      feedBarrel(c, x + w - 47, y + 61, '#b4a36c');
    }
    if (level === 3) {
      // A dosing manifold spans the gap between the two raceways.
      rect(c, x + 26, y + 57, pondWidth - 24, 7, '#43695c');
      rect(c, x + 26, y + 57, pondWidth - 24, 3, '#d5d7af');
      for (let i = 0; i < 4; i++) {
        const outlet = x + 37 + i * 46;
        rect(c, outlet, y + 53, 5, 15, '#d4d9b3');
        rect(c, outlet - 2, y + 58, 9, 4, '#7f9d7b');
      }
      operatingLight(c, world, cabinetX + 33, cabinetY + 7, t);
    }
  }
  rect(c, x + 8, y - 12, 47, 12, '#cfb57e');
  rect(c, x + 12, y - 10, 39, 2, '#f0deb0');
  c.fillStyle = INK; c.font = 'bold 8px system-ui'; c.textAlign = 'center'; c.fillText('RACEWAY', x + 31, y - 3);
}

function greenhouse(c, world, s) {
  const x = s.x * 32, y = s.y * 32, w = s.w * 32, h = s.h * 32;
  shadow(c, x - 3, y + h - 10, w + 6, 24);
  pixelPanel(c, x, y + 31, w, h - 31, '#56786c', 4);
  rect(c, x + 4, y + 39, w - 8, h - 51, '#638f7b');
  // A stepped arched roof uses the same two-pixel edges as the sprite art.
  for (let i = 0; i < 5; i++) {
    rect(c, x + 4 + i * 6, y + 26 - i * 8, w - 8 - i * 12, 10, i < 2 ? '#aac5b0' : '#bdd0b6');
  }
  rect(c, x + 32, y - 10, w - 64, 6, '#e3e5c9');
  rect(c, x - 4, y + 30, w + 8, 6, '#e1dfbd');
  const light = world.led;
  for (let i = 0; i < 5; i++) {
    const px = x + 11 + i * 41;
    rect(c, px, y + 43, 32, 88, '#497763');
    rect(c, px + 3, y + 47, 26, 74, light ? '#b0ba72' : '#81ac91');
    rect(c, px + 6, y + 54, 4, 56, light ? '#d6d797' : '#adccb0');
    rect(c, px + 14, y + 82, 12, 29, '#467c59');
    rect(c, px + 13, y + 79, 14, 5, '#90b077');
    rect(c, px + 3, y + 48, 26, 3, light ? '#fff0a6' : '#b9d2b4');
    if (light) {
      rect(c, px + 1, y + 53, 30, 28, '#f3df7238');
      rect(c, px + 3, y + 81, 26, 22, '#f3df721c');
    }
    rect(c, px - 6, y + 35, 5, h - 42, '#d9dfbe');
    rect(c, px + 1, y + 123, 30, 5, '#b7c4a3');
  }
  rect(c, x + w - 6, y + 35, 5, h - 42, '#d9dfbe');
  rect(c, x - 1, y + h - 13, w + 2, 9, '#aaa98c');
  rect(c, x + w / 2 - 17, y + h - 41, 34, 37, '#365d51');
  rect(c, x + w / 2 - 12, y + h - 37, 24, 28, '#8bb49a');
  rect(c, x + w / 2 + 7, y + h - 25, 3, 4, '#e9d49a');
  rect(c, x + w / 2 - 22, y + h - 4, 44, 5, '#ded5b0');
}

function processing(c, world, s, t) {
  const x = s.x * 32, y = s.y * 32, w = s.w * 32, h = s.h * 32;
  const level = farmLevel(world, 'processing');
  shadow(c, x - 8, y + h - 7, w + 13, 22);
  pixelPanel(c, x, y + 29, w, h - 29, '#b99c72', 4);
  rect(c, x + 4, y + 37, w - 8, h - 45, '#e0c28e');
  rect(c, x + 3, y + h - 14, w - 6, 9, '#b29269');
  for (let yy = y + 49; yy < y + h - 15; yy += 18) {
    rect(c, x + 5, yy, w - 10, 2, '#d0b180');
    for (let xx = x + 12 + (yy % 36 ? 0 : 12); xx < x + w; xx += 36) rect(c, xx, yy - 14, 2, 14, '#d0b180');
  }
  rect(c, x - 8, y + 2, w + 16, 43, '#715748');
  rect(c, x - 6, y - 4, w + 12, 42, '#a36b4e');
  rect(c, x + 4, y - 12, w - 8, 10, '#be845b');
  for (let yy = 0; yy < 3; yy++) {
    rect(c, x - 2, y + yy * 12, w + 4, 2, '#c28b60');
    for (let xx = 0; xx < 7; xx++) rect(c, x + 10 + xx * 31 + yy % 2 * 12, y + yy * 12 + 2, 2, 9, '#925d48');
  }
  for (let i = 0; i < 3; i++) {
    const px = x + 13 + i * 60;
    rect(c, px, y + 2, 51, 28, '#304f54'); rect(c, px + 3, y + 5, 45, 21, '#416f7a');
    for (let n = 1; n < 3; n++) rect(c, px + 3 + n * 15, y + 5, 1, 21, '#91b2b0');
    rect(c, px + 3, y + 15, 45, 1, '#91b2b0');
  }
  rect(c, x + 20, y + 58, 46, 39, '#856f53'); rect(c, x + 23, y + 61, 40, 30, '#638c88');
  rect(c, x + 28, y + 64, 30, 3, '#b7d3bc'); rect(c, x + 42, y + 61, 3, 30, '#d1c19b');
  rect(c, x + 119, y + 60, 44, 68, '#6e6750'); rect(c, x + 123, y + 64, 36, 61, '#967a54');
  rect(c, x + 125, y + 70, 2, 48, '#b69968'); rect(c, x + 151, y + 93, 3, 5, '#e0d5a6');
  // Small pressure vessel and pipe by the workshop door.
  pixelPanel(c, x + 183, y + 58, 29, 52, '#72958b', 5);
  rect(c, x + 187, y + 62, 6, 38, '#b8c9ad'); rect(c, x + 182, y + 62, 31, 5, '#d2d6b5');
  rect(c, x + 192, y + 52, 9, 7, '#bdc4a1'); rect(c, x + 201, y + 83, 15, 6, '#cad0ad');
  if (level >= 1) {
    // An efficient process unit fills the workshop's empty front bay.
    pixelPanel(c, x + 76, y + 58, 34, 55, '#4e746a', 3);
    rect(c, x + 79, y + 60, 28, 48, '#a7b79a');
    rect(c, x + 82, y + 64, 22, 12, '#3d675f');
    rect(c, x + 85, y + 67, 13, 3, '#b4cf92');
    for (let i = 0; i < 4; i++) rect(c, x + 83, y + 83 + i * 5, 20, 2, '#6d8b7a');
    rect(c, x + 78, y + 110, 30, 5, '#d4d2aa');
  }
  if (level >= 2) {
    // Insulated connections and a roof ventilator suggest improved equipment.
    rect(c, x + w - 19, y + 18, 6, 42, '#6d8674');
    rect(c, x + w - 18, y + 18, 2, 42, '#d9d9b4');
    pixelPanel(c, x + w - 33, y - 4, 25, 30, '#486861', 3);
    rect(c, x + w - 30, y - 1, 19, 23, '#b4c0a1');
    for (let i = 0; i < 4; i++) rect(c, x + w - 28, y + 3 + i * 5, 15, 2, '#627f70');
    rect(c, x + w - 35, y + 24, 29, 4, '#d3d2ad');
    rect(c, x + 183, y + 72, 29, 25, '#c5ccb0');
    rect(c, x + 188, y + 74, 5, 20, '#e1e0bc');
    rect(c, x + 184, y + 80, 27, 3, '#97ad92');
  }
  if (level === 3) {
    pixelPanel(c, x + 73, y + 47, 40, 69, '#3b635a', 3);
    rect(c, x + 77, y + 50, 32, 60, '#c6cdab');
    rect(c, x + 81, y + 55, 24, 15, '#3b675e');
    rect(c, x + 84, y + 59, 15, 3, '#b6d29b');
    rect(c, x + 82, y + 76, 21, 3, '#7e9a81');
    for (let i = 0; i < 4; i++) rect(c, x + 82, y + 86 + i * 5, 21, 2, '#799580');
    rect(c, x + 70, y + 113, 46, 5, '#8c9d7f');
    pixelPanel(c, x + 188, y + 66, 18, 14, '#56776b', 2);
    rect(c, x + 192, y + 69, 10, 7, '#dce1b7');
    rect(c, x + 196, y + 70, 2, 5, '#668a6e');
    operatingLight(c, world, x + 99, y + 78, t + 500);
  }
  if (['recovery', 'delivery', 'results'].includes(world.phase)) crate(c, x + 72, y + h - 22, true);
}

function tank(c, x, y, w, h, t, reduced) {
  shadow(c, x, y + h - 5, w, 15);
  pixelPanel(c, x, y + 5, w, h - 5, '#4d776e', 6);
  rect(c, x + 5, y + 11, w - 12, h - 16, '#7a9c8c'); rect(c, x + 9, y + 13, 8, h - 20, '#a5bd9f');
  pixelPanel(c, x - 3, y, w + 6, 15, '#c2ccb0', 5); rect(c, x + 5, y + 3, w - 10, 3, '#e6e4c6');
  rect(c, x + 1, y + h - 18, w - 2, 6, '#b8c4a6');
  rect(c, x + w / 2 - 4, y + 28, 13, h - 56, '#365e59');
  rect(c, x + w / 2 - 1, y + 32, 7, h - 64, '#7eb7ac');
  const offset = reduced ? 0 : Math.floor(t / 240) % 3 * 3;
  for (let i = 0; i < 3; i++) rect(c, x + w / 2 + 1, y + 36 + i * 8 - offset, 2, 2, '#d1dfbe');
}

function recovery(c, world, s, t) {
  const x = s.x * 32, y = s.y * 32;
  const level = farmLevel(world, 'recovery');
  if (level === 3) {
    rect(c, x + 46, y + 4, 105, 7, '#54796b');
    rect(c, x + 46, y + 4, 105, 3, '#d7d7b0');
  }
  rect(c, x + 38, y + 91, 101, 12, '#4d776e'); rect(c, x + 38, y + 91, 101, 5, '#cfcead');
  rect(c, x + 130, y + 80, 10, 45, '#638578'); rect(c, x + 130, y + 80, 4, 45, '#cbd0ad');
  tank(c, x + 8, y + 6, 77, 106, t, world.reduced);
  tank(c, x + 115, y + (level >= 2 ? 8 : 34), 65, level >= 2 ? 104 : 78, t + 180, world.reduced);
  rect(c, x + 41, y + 111, 12, 14, '#738b73'); rect(c, x + 38, y + 120, 18, 5, '#bbc4a1');
  rect(c, x + 94, y + 89, 4, 14, '#335e55'); rect(c, x + 88, y + 93, 16, 5, '#d3a06a');
  if (level >= 1) {
    rect(c, x + 99, y + 63, 5, 30, '#c9d1af');
    feedBarrel(c, x + 89, y + 35, '#75a399');
    rect(c, x + 98, y + 46, 6, 14, '#b6d6b7');
  }
  if (level >= 2) {
    rect(c, x + 145, y + 28, 9, 56, '#557c73');
    rect(c, x + 147, y + 31, 5, 47, '#8dc4b2');
    rect(c, x + 144, y + 85, 12, 3, '#d9ddb6');
  }
  if (level === 3) {
    // A filter column and small controller complete the recovery loop.
    pixelPanel(c, x + 89, y + 19, 24, 67, '#4d7468', 3);
    rect(c, x + 93, y + 23, 16, 58, '#b8c7a3');
    rect(c, x + 96, y + 27, 9, 38, '#759e86');
    for (let i = 0; i < 4; i++) rect(c, x + 94, y + 32 + i * 10, 14, 3, '#d6ddae');
    rect(c, x + 87, y + 78, 28, 6, '#d3d7af');
    pixelPanel(c, x + 88, y + 103, 27, 21, '#4b7163', 2);
    rect(c, x + 91, y + 105, 21, 14, '#ccd0aa');
    rect(c, x + 94, y + 108, 8, 5, '#547c68');
    operatingLight(c, world, x + 105, y + 109, t + 1000);
  }
}

function crate(c, x, y, product = false) {
  rect(c, x, y, 28, 24, '#8b6b43'); rect(c, x + 2, y, 24, 20, '#ba9159');
  rect(c, x + 3, y + 3, 22, 3, '#e0b771'); rect(c, x + 3, y + 13, 22, 3, '#e0b771');
  rect(c, x + 4, y + 3, 3, 15, '#8c6b43'); rect(c, x + 21, y + 3, 3, 15, '#8c6b43');
  if (product) {rect(c, x + 10, y - 3, 9, 10, '#6c9768'); rect(c, x + 12, y - 6, 5, 4, '#d6dab6');}
}

function delivery(c, s) {
  const x = s.x * 32, y = s.y * 32, w = s.w * 32;
  shadow(c, x, y + 86, w, 18);
  rect(c, x + 6, y + 24, w - 12, 65, '#c9af7f');
  rect(c, x + 12, y + 36, w - 24, 42, '#628475');
  rect(c, x + 12, y + 30, 7, 61, '#b18a56'); rect(c, x + w - 19, y + 30, 7, 61, '#b18a56');
  rect(c, x - 6, y + 14, w + 12, 24, '#806548');
  for (let i = 0; i < 12; i++) {
    const xx = x - 5 + i * 17;
    rect(c, xx, y + 8, 17, 24, i % 2 ? '#cf8c52' : '#eee0ab');
    rect(c, xx, y + 29, 17, 8, i % 2 ? '#b77649' : '#cbbc8d');
  }
  rect(c, x + 10, y + 70, w - 20, 13, '#8e6b44'); rect(c, x + 12, y + 68, w - 24, 5, '#d1b27b');
  crate(c, x + 22, y + 49, true); crate(c, x + 54, y + 47, true);
  rect(c, x + 118, y + 48, 16, 18, '#e0d8b3'); rect(c, x + 121, y + 51, 10, 10, '#71a376');
  rect(c, x + 146, y + 52, 12, 14, '#c5caa6'); rect(c, x + 149, y + 49, 6, 4, '#6d8f78');
  rect(c, x + 16, y + 84, 7, 12, '#756344'); rect(c, x + w - 24, y + 84, 7, 12, '#756344');
}

function stationLabel(c, world, id, s, t) {
  const x = (s.x + s.w / 2) * 32, y = s.y * 32 - 40;
  const active = id === world.active, width = Math.max(96, s.name.length * 7 + 24);
  pixelPanel(c, x - width / 2 + 2, y + 3, width, 24, '#3f5b4438', 3);
  pixelPanel(c, x - width / 2, y, width, 24, active ? '#f5dda2' : '#e9e2bf', 3);
  rect(c, x - width / 2 + 6, y + 4, 3, 16, active ? '#b88346' : '#8b9d78');
  c.fillStyle = INK; c.font = '600 12px system-ui'; c.textAlign = 'center'; c.fillText(s.name, x + 3, y + 16);
  const level = farmLevel(world, id);
  if (level) {
    const bx = x + width / 2 + 5;
    pixelPanel(c, bx, y + 2, 28, 20, '#806a43', 2);
    rect(c, bx + 2, y + 3, 24, 15, '#c7ad70');
    rect(c, bx + 3, y + 4, 22, 2, '#e0c88d');
    c.fillStyle = '#526047'; c.font = 'bold 11px Georgia'; c.fillText(['', 'I', 'II', 'III'][level], bx + 14, y + 16);
  }
  if (active && world.enabled) {
    const px = (s.point[0] + .5) * 32, py = (s.point[1] + .5) * 32;
    const lift = world.reduced ? 0 : Math.round(Math.sin(t / 320) * 3);
    rect(c, px - 12, py + 3, 24, 2, '#f9e6ae'); rect(c, px - 15, py - 1, 2, 7, '#f9e6ae'); rect(c, px + 13, py - 1, 2, 7, '#f9e6ae');
    const by = y + 2 + lift, bx = x - width / 2 - 17;
    pixelPanel(c, bx - 10, by, 20, 20, '#365d50', 3);
    rect(c, bx - 3, by + 4, 6, 7, '#ffe5a0'); rect(c, bx - 6, by + 11, 12, 3, '#ffe5a0'); rect(c, bx - 3, by + 14, 6, 3, '#ffe5a0');
  }
}

function fieldPlaque(c, world) {
  const {x, y} = SECRETS.find(secret => secret.id === 'eel');
  const logo = world.images.eelLogo;
  if (!world.discoveredSecrets?.has('eel')) {
    // Before discovery this is a small weathered detail in the grass.
    rect(c, x - 10, y + 11, 20, 3, '#304f4925');
    rect(c, x - 2, y + 7, 4, 10, '#788268');
    pixelPanel(c, x - 12, y - 10, 24, 18, '#7d896d', 2);
    rect(c, x - 10, y - 8, 20, 14, '#b1b59a');
    if (logo?.naturalWidth) {
      const fit = Math.min(18 / logo.naturalWidth, 12 / logo.naturalHeight);
      const width = logo.naturalWidth * fit, height = logo.naturalHeight * fit;
      c.save(); c.globalAlpha = .55;
      c.drawImage(logo, Math.round(x - width / 2), Math.round(y - 1 - height / 2), width, height);
      c.restore();
    }
    return;
  }
  shadow(c, x - 24, y + 20, 44, 9);
  rect(c, x - 18, y + 13, 5, 18, '#6a6846'); rect(c, x + 13, y + 13, 5, 18, '#6a6846');
  pixelPanel(c, x - 25, y - 23, 50, 39, '#6b775b', 3);
  pixelPanel(c, x - 23, y - 21, 46, 35, '#c3b98a', 2);
  rect(c, x - 21, y - 19, 42, 30, '#e8e2c5');
  rect(c, x - 23, y + 12, 46, 2, '#a59c72');
  rect(c, x - 21, y - 20, 4, 2, '#eee7ca'); rect(c, x + 17, y + 9, 3, 2, '#c8c3a3');
  if (logo?.naturalWidth) {
    // Fit the whole official image; retain its aspect ratio and all lettering.
    const fit = Math.min(39 / logo.naturalWidth, 26 / logo.naturalHeight);
    const width = logo.naturalWidth * fit, height = logo.naturalHeight * fit;
    c.drawImage(logo, Math.round(x - width / 2), Math.round(y - 4 - height / 2), width, height);
  }
}

function discoveredMarkers(c, world, t) {
  for (const secret of SECRETS) {
    if (!world.discoveredSecrets?.has(secret.id)) continue;
    const x = secret.x + 21, y = secret.y - 17 + (world.reduced ? 0 : Math.round(Math.sin(t / 480 + secret.x) * 2));
    rect(c, x - 1, y - 4, 2, 9, '#f5dfa0'); rect(c, x - 4, y - 1, 8, 2, '#f5dfa0');
    rect(c, x - 1, y - 1, 2, 2, '#fff3c5');
  }
}

function atmosphere(c, world, t) {
  const mix = world.reduced ? (world.cloudy ? Math.max(0, Math.min(1.5, world.weatherIntensity ?? 1)) : 0) : world.weatherMix;
  if (!mix) return;
  rect(c, 0, 0, WORLD_W, WORLD_H, `rgba(66,85,98,${mix * .13})`);
  // Broad cloud shadows drift over the fields without hiding the controls.
  for (let i = 0; i < 3; i++) {
    const x = world.reduced ? i * 360 - 60 : (t / 48 + i * 410) % 1450 - 280;
    const y = 46 + i * 172;
    pixelPanel(c, x, y + 30, 230, 54, `rgba(43,65,70,${mix * .09})`, 18);
    pixelPanel(c, x + 34, y + 14, 154, 68, `rgba(43,65,70,${mix * .05})`, 16);
  }
  // Clouds stay near the northern edge; the greenhouses remain readable.
  c.globalAlpha = Math.min(1, mix * .86);
  for (let i = 0; i < 3; i++) {
    const x = world.reduced ? i * 400 : (t / 90 + i * 400) % 1350 - 170;
    const y = 2 + i % 2 * 18;
    pixelPanel(c, x, y + 12, 125, 25, '#bac7bd', 8);
    pixelPanel(c, x + 8, y + 4, 105, 25, '#e2e4cd', 9);
    pixelPanel(c, x + 32, y - 4, 51, 21, '#edecda', 8);
  }
  c.globalAlpha = 1;
}

export function drawFarmScene(world, t) {
  const c = world.ctx, w = world.width || WORLD_W, h = world.height || 560, scale = world.scale || 1;
  world.camX = Math.round(Math.max(0, Math.min(Math.max(0, WORLD_W - w / scale), world.avatar.x - w / scale / 2)));
  world.camY = Math.round(Math.max(0, Math.min(Math.max(0, WORLD_H - h / scale), world.avatar.y - h / scale / 2)));
  c.setTransform(world.dpr || 1, 0, 0, world.dpr || 1, 0, 0); c.clearRect(0, 0, w, h);
  c.fillStyle = '#86a65e'; c.fillRect(0, 0, w, h);
  if (!world.artReady) {c.fillStyle = INK; c.font = '14px system-ui'; c.textAlign = 'center'; c.fillText('Preparando a fazenda…', w / 2, h / 2); return;}
  c.save(); c.imageSmoothingEnabled = false; c.scale(scale, scale); c.translate(-world.camX, -world.camY);
  if (world.ground) c.drawImage(world.ground, 0, 0);
  const clock = world.reduced ? 0 : t;
  // River shimmer is an original overlay beside the Kenney terrain.
  for (let i = 0; i < 16; i++) rect(c, 965 + i % 2 * 28 + (clock / 160 + i * 5) % 9, 17 + i * 42, 13, 2, '#c4d7c077');
  if (world.path.length) {
    c.globalAlpha = .6;
    for (let i = 1; i < world.path.length; i += 2) {const p = world.path[i]; rect(c, p.x - 2, p.y - 1, 4, 3, '#f9efc8');}
    c.globalAlpha = 1;
  }
  const things = [];
  things.push({depth: 199, draw: () => fieldPlaque(c, world)});
  for (const layer of SCENE_MAP.layers.filter(l => l.type === 'objectgroup' && l.name === 'Scenery')) {
    for (const o of layer.objects) if (o.gid) {
      const properties = Object.fromEntries((o.properties || []).map(p => [p.name, p.value]));
      things.push({depth: (properties.footY ?? o.y) * 2, draw: () => {
        if (properties.castShadow !== false) shadow(c, o.x * 2, o.y * 2 - 9, o.width * 2, 12);
        tile(c, world, o.gid, o.x * 2, (o.y - o.height) * 2, o.width * 2, o.height * 2);
      }});
    }
  }
  for (const [id, s] of Object.entries(STATIONS)) things.push({depth: (s.y + s.h) * 32, draw: () => {
    if (id === 'cultivation') cultivation(c, world, s, clock);
    else if (id === 'weather') greenhouse(c, world, s);
    else if (id === 'processing') processing(c, world, s, clock);
    else if (id === 'recovery') recovery(c, world, s, clock);
    else delivery(c, s);
  }});
  things.push({depth: world.avatar.y, draw: () => {
    const x = Math.round(world.avatar.x), y = Math.round(world.avatar.y);
    shadow(c, x - 15, y - 8, 24, 8);
    const frame = world.moving && !world.reduced ? Math.floor(world.walkTime * 8) % 4 : 0;
    const row = {down: 0, left: 1, right: 2, up: 3}[world.avatar.facing] ?? 0;
    sprite(c, world.images.researcher, frame, row, 16, 24, x - 16, y - 46);
  }});
  things.sort((a, b) => a.depth - b.depth).forEach(o => o.draw());
  atmosphere(c, world, clock);
  discoveredMarkers(c, world, clock);
  for (const [id, s] of Object.entries(STATIONS)) stationLabel(c, world, id, s, clock);
  c.restore();
}
