// These are deliberately simplified teaching profiles, not measured yields or
// universal compositions of the named organisms. Biomass uses game units.
export const SPECIES_MODEL_NOTE = 'Perfis didáticos do jogo, sem equivalência com rendimentos medidos ou composição universal de uma espécie.';

const speciesProfileValue = (biomass, lipid, starch) => Object.freeze({biomass, lipid, starch});
const speciesStorageProfiles = (biodiesel, material = biodiesel) => Object.freeze({biodiesel, material});

export const SPECIES = Object.freeze({
  chlorella: Object.freeze({
    id: 'chlorella', name: 'Chlorella vulgaris', shortName: 'Chlorella',
    focus: 'Perfil de referência', supportsStarch: true,
    description: 'Uma opção versátil para começar. Mantém os perfis originais do jogo para comparar biodiesel, biomassa integral e amido.',
    requirements: Object.freeze({batches: 0, level: 1}),
    profiles: Object.freeze({growth: speciesProfileValue(100, .22, .28),
      storage: speciesStorageProfiles(speciesProfileValue(78, .40, .20), speciesProfileValue(78, .18, .50))})
  }),
  nannochloropsis: Object.freeze({
    id: 'nannochloropsis', name: 'Nannochloropsis gaditana', shortName: 'Nannochloropsis',
    focus: 'Lipídios para biodiesel', supportsStarch: false,
    description: 'Neste cenário, favorece a rota de óleo. Para bioplástico, use biomassa integral; a rota de amido não está disponível.',
    requirements: Object.freeze({batches: 2, level: 1}),
    source: 'https://pmc.ncbi.nlm.nih.gov/articles/PMC4248700/',
    profiles: Object.freeze({growth: speciesProfileValue(100, .30, 0),
      storage: speciesStorageProfiles(speciesProfileValue(80, .50, 0))})
  }),
  tetraselmis: Object.freeze({
    id: 'tetraselmis', name: 'Tetraselmis subcordiformis', shortName: 'Tetraselmis',
    focus: 'Biomassa e amido para materiais', supportsStarch: true,
    description: 'Neste cenário, produz mais biomassa e favorece materiais com amido. A fração menor de lipídios pede outra estratégia para biodiesel.',
    requirements: Object.freeze({batches: 3, level: 3}),
    source: 'https://pubmed.ncbi.nlm.nih.gov/22717561/',
    profiles: Object.freeze({growth: speciesProfileValue(125, .18, .38),
      storage: speciesStorageProfiles(speciesProfileValue(100, .16, .60))})
  })
});

export function normalizeSpeciesId(id = 'chlorella') {
  if (typeof id !== 'string' || !Object.hasOwn(SPECIES, id)) throw new Error('Espécie desconhecida');
  return id;
}

export function getSpecies(id) {
  return SPECIES[normalizeSpeciesId(id)];
}

export function speciesProfile(id, contract, choice) {
  const species = getSpecies(id);
  if (!['biodiesel', 'material'].includes(contract)) throw new Error('Contrato desconhecido');
  if (choice === 'growth') return species.profiles.growth;
  if (choice === 'storage') return species.profiles.storage[contract];
  throw new Error('Perfil de cultivo desconhecido');
}
