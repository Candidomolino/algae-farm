// Discoveries are optional field notes. They never alter production/resources.
export const SECRETS = Object.freeze([
  Object.freeze({
    id: 'eel', name: 'A placa esquecida', title: 'Uma visita à EEL!',
    body: 'Você encontrou a marca da Escola de Engenharia de Lorena da Universidade de São Paulo. Até uma pequena fazenda de algas pode esconder uma homenagem à escola!',
    hint: 'Entre os tanques de cultivo e a estufa, uma pequena placa guarda uma assinatura.',
    x: 472, y: 168
  }),
  Object.freeze({
    id: 'mushroom', name: 'O visitante do jardim', title: 'Um vizinho curioso',
    body: 'Um cogumelo resolveu visitar o jardim. Ele é só uma surpresa do cenário: não entra na biomassa de microalgas, nas contas do lote nem na receita do bioplástico.',
    hint: 'Perto da cerca à esquerda do cultivo, há um visitante que não é uma microalga.',
    x: 80, y: 144
  }),
  Object.freeze({
    id: 'stump', name: 'O velho caderno de campo', title: 'Uma anotação entre as raízes',
    body: 'No velho tronco, você encontrou uma anotação: “Compare as escolhas e as condições do ensaio. Mais produto pode exigir mais energia, água ou tempo.” O caderno não concede recursos extras; a pista é pensar como engenheiro.',
    hint: 'À direita da recuperação de água, um velho tronco guarda uma anotação de campo.',
    x: 336, y: 400
  })
]);

const SECRET_IDS = new Set(SECRETS.map(secret => secret.id));

export function validSecretIds(raw) {
  if (!Array.isArray(raw)) return [];
  return [...new Set(raw.filter(id => typeof id === 'string' && SECRET_IDS.has(id)))];
}

// The hit radius is always 22 CSS pixels, independent of map/camera zoom.
export function findSecretAt(wx, wy, scale = 1) {
  if (![wx, wy, scale].every(Number.isFinite) || scale <= 0) return null;
  const radius = 22 / scale;
  let closest = null, closestDistance = Infinity;
  for (const secret of SECRETS) {
    const distance = Math.hypot(wx - secret.x, wy - secret.y);
    if (distance <= radius && distance < closestDistance) {closest = secret; closestDistance = distance;}
  }
  return closest;
}
